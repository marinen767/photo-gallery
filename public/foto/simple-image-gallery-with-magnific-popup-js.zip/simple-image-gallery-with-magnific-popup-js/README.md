# Simple Image Gallery with magnific-popup.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/JiiB/pen/xgdOjw](https://codepen.io/JiiB/pen/xgdOjw).

This simple and clean looking Image Gallery was created with the magnific-popup jQuery plugin