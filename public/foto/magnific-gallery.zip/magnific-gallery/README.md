# Magnific Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/mican/pen/awxmpY](https://codepen.io/mican/pen/awxmpY).

Nice responsive gallery with:

&#9642; CSS columns &#9642; roll over, hover caption

&#9642; Magnific Popup script &#9642; Zoom in effect

&#9642; Haml & Sass & CoffeeScript

[NEW VERSION](https://codepen.io/mican/pen/RyjZgm)
